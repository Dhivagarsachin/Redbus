import pandas as pd
import glob
# df = pd.read_csv("ap_bus_details.csv")
# df = pd.read_csv("assam_bus_details.csv")
# df = pd.read_csv("chandigarh_bus_details.csv")
# df = pd.read_csv("himachal_bus_details.csv")
# df = pd.read_csv("kaac_bus_details.csv")
# df = pd.read_csv("kerala_bus_details.csv")
# df = pd.read_csv("rajasthan_bus_details.csv")
# df = pd.read_csv("sb_bus_details.csv")
# df = pd.read_csv("Telangana_bus_details.csv")
# df = pd.read_csv("up_bus_details.csv")
# df = pd.read_csv("wb_bus_details.csv")
# df = pd.read_csv("wb2_bus_details.csv")
df = pd.read_csv("jk_bus_details.csv")

# List of CSV file paths
csv_files = ["ap_bus_details.csv", "assam_bus_details.csv", "chandigarh_bus_details.csv", "himachal_bus_details.csv", "kaac_bus_details.csv", "kerala_bus_details.csv","rajasthan_bus_details.csv", "sb_bus_details.csv", "Telangana_bus_details.csv", "up_bus_details.csv", "wb_bus_details.csv", "wb2_bus_details.csv", "jk_bus_details.csv"]   

# Read each CSV file into a DataFrame and store it in a list
# df = [pd.read_csv(file) for file in csv_files]
df = df.dropna()
# Concatenate all DataFrames in the list
# combined_df = pd.concat(df, ignore_index=True)
# print(cleanedList)
# combined_df.to_csv("bus_routes.csv", index=False)

#add id column
# id_column = pd.Series(range(1, len(df) + 1), name='id')
# df = pd.concat([id_column, df], axis=1)
# df = pd.read_csv("bus_routes.csv")

# replace string to empty string
df['Price'] = df['Price'].str.replace('INR ', '')

#extract the digits(0-9)
# df['Seat_Availability'] = df['Seat_Availability'].str.extract('(\d+)')
df['Seat_Availability'] = df['Seat_Availability'].str.extract(r'(\d+)')

#python mysql connection
import pymysql
myconnection = pymysql.connect(host='127.0.0.1', user='root',passwd='123456789',database="redbus")
# df = pd.read_csv("bus_routes.csv")
df = df.dropna() #drop null values
a = ",".join(f"{i} {j}"
for i,j in zip(df.columns,df.dtypes)).replace("float64","float").replace("object","text").replace("int64","int") #replace dtypes from pandas to mysql
table_name = "bus_routes"

table_check_query=f" select count(*) from information_schema.tables where table_schema='redbus' and table_name='{table_name}';"
cursor=myconnection.cursor()
cursor.execute(table_check_query)
if cursor.fetchone()[0]==0: 
    myconnection.cursor().execute(f"create table {table_name} ({a})")
for i in range(len(df)):
    myconnection.cursor().execute(f"insert into {table_name} values {tuple(df.iloc[i])}")
    myconnection.commit()
